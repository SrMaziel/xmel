﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InformacionCrud.Shared
{
    public class TipodocumentoDTO
    {
        public int Idtipodocumentos { get; set; }

        public string? Tipodocumentos { get; set; }

        public ulong? Estado { get; set; }
    }
}
