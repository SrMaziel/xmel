﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InformacionCrud.Shared
{
    public class NacionalidadDTO
    {
        public int Idnacionalidad { get; set; }

        public string? Nacionalidad1 { get; set; }

        public ulong? Estado { get; set; }
    }
}
