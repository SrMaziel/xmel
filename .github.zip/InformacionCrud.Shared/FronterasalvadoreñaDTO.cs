﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InformacionCrud.Shared
{
    public class FronterasalvadoreñaDTO
    {
        public int Idfronterasalvadoreñas { get; set; }

        public string? Fronteras { get; set; }

        public ulong? Estado { get; set; }
    }
}
