﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InformacionCrud.Shared
{
    public class TiposdelitoDTO
    {
        public int Idtiposdelitos { get; set; }

        public string? Tiposdelitos { get; set; }

        public ulong? Estado { get; set; }
    }
}
